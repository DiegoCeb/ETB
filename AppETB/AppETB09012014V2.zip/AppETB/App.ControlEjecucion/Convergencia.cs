﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.ControlEjecucion
{
    /// <summary>
    /// Clase Convergencia
    /// </summary>
    public class Convergencia
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public Convergencia()
        {

        }
    }
}
